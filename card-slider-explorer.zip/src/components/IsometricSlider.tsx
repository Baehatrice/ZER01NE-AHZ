import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Compass, Sparkles, Sliders, Layers, ChevronLeft, ChevronRight, Eye, Grid3X3 } from 'lucide-react';
import { CardItem } from '../types';
import Isometric3DObjects from './Isometric3DObjects';

interface IsometricSliderProps {
  cards: CardItem[];
  activeIndex: number;
  setActiveIndex: (index: number) => void;
  onSelectCard: (card: CardItem) => void;
}

function interpolateColor(color1: string, color2: string, factor: number) {
  const parse = (c: string) => {
    const raw = c.replace('#', '');
    if (raw.length === 3) {
      return [
        parseInt(raw[0] + raw[0], 16),
        parseInt(raw[1] + raw[1], 16),
        parseInt(raw[2] + raw[2], 16),
      ];
    }
    return [
      parseInt(raw.substring(0, 2), 16),
      parseInt(raw.substring(2, 4), 16),
      parseInt(raw.substring(4, 6), 16),
    ];
  };
  const [r1, g1, b1] = parse(color1);
  const [r2, g2, b2] = parse(color2);
  const r = Math.round(r1 + factor * (r2 - r1));
  const g = Math.round(g1 + factor * (g2 - g1));
  const b = Math.round(b1 + factor * (b2 - b1));
  return `rgb(${r}, ${g}, ${b})`;
}

export default function IsometricSlider({
  cards,
  activeIndex,
  setActiveIndex,
  onSelectCard,
}: IsometricSliderProps) {
  // Configurable 3D Angles
  const [pitch, setPitch] = useState(55); // RotateX (45 deg - 65 deg)
  const [yaw, setYaw] = useState(-35);   // RotateZ (-25 deg - -50 deg)
  const [altitude, setAltitude] = useState(40); // 3D Elevation spacing of active card
  const [spreadMode, setSpreadMode] = useState<'row' | 'stack' | 'spiral'>('row');
  const presentationStep = activeIndex === 2 ? 2 : 1;

  // Define 26 visual nodes in 3D space
  const spaceNodes = React.useMemo(() => {
    const nodes = [];
    
    // Node 0: A (Real Card index 0)
    nodes.push({
      isReal: true,
      letter: 'A',
      idx: 0,
      color: '#ec4899',
      realCardIndex: 0,
      realCard: cards[0]
    });

    // Nodes 1-6: b, c, d, e, f, g (6 virtual nodes)
    const bToG = ['B', 'C', 'D', 'E', 'F', 'G'];
    bToG.forEach((letter, i) => {
      const factor = (i + 1) / 7;
      const col = interpolateColor('#ec4899', '#a3e635', factor);
      nodes.push({
        isReal: false,
        letter,
        idx: i + 1,
        color: col
      });
    });

    // Node 7: H (Real Card index 1)
    nodes.push({
      isReal: true,
      letter: 'H',
      idx: 7,
      color: '#a3e635',
      realCardIndex: 1,
      realCard: cards[1]
    });

    // Nodes 8-24: i to y (17 virtual nodes)
    const iToY = ['I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y'];
    iToY.forEach((letter, i) => {
      const factor = (i + 1) / 18;
      const col = interpolateColor('#a3e635', '#c084fc', factor);
      nodes.push({
        isReal: false,
        letter,
        idx: i + 8,
        color: col
      });
    });

    // Node 25: Z (Real Card index 2)
    nodes.push({
      isReal: true,
      letter: 'Z',
      idx: 25,
      color: '#c084fc',
      realCardIndex: 2,
      realCard: cards[2]
    });

    return nodes;
  }, [cards]);

  const handleNext = () => {
    setActiveIndex((activeIndex + 1) % cards.length);
  };

  const handlePrev = () => {
    setActiveIndex((activeIndex - 1 + cards.length) % cards.length);
  };

  // Keyboard Navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') handlePrev();
      if (e.key === 'ArrowRight') handleNext();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeIndex]);

  return (
    <div id="isometric-canvas-panel" className="relative w-full flex flex-col items-center">
      
      {/* Real-time 45deg Angel Controller HUD Panel */}
      <div className="w-full max-w-xl mx-auto mb-6 bg-zinc-950/60 backdrop-blur-md rounded-2xl border border-zinc-900 p-4 text-xs font-mono text-zinc-400 flex flex-col gap-3">
        <div className="flex items-center justify-between border-b border-zinc-900 pb-2">
          <span className="text-[11px] font-bold text-zinc-200 flex items-center gap-1.5 uppercase">
            <Sliders className="w-3.5 h-3.5 text-rose-400" /> Aerial Perspective Setup (45° View)
          </span>
          <span className="text-[10px] text-zinc-500">DYNAMIC 3D PERSPECTIVE ENGINE</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Pitch Slider (Rotate X) */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between">
              <span>View Pitch (X):</span>
              <span className="text-white font-bold">{pitch}°</span>
            </div>
            <input 
              type="range" 
              min="30" 
              max="70" 
              value={pitch} 
              onChange={(e) => setPitch(Number(e.target.value))}
              className="w-full accent-rose-500 bg-zinc-900 h-1.5 rounded-lg cursor-pointer"
            />
          </div>

          {/* Yaw Slider (Rotate Z) */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between">
              <span>View Yaw (Z):</span>
              <span className="text-white font-bold">{yaw}°</span>
            </div>
            <input 
              type="range" 
              min="-60" 
              max="0" 
              value={yaw} 
              onChange={(e) => setYaw(Number(e.target.value))}
              className="w-full accent-emerald-400 bg-zinc-900 h-1.5 rounded-lg cursor-pointer"
            />
          </div>

          {/* Elevate Active Card (Z Translation) */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between">
              <span>Active Lift (Z):</span>
              <span className="text-white font-bold">+{altitude}px</span>
            </div>
            <input 
              type="range" 
              min="20" 
              max="80" 
              value={altitude} 
              onChange={(e) => setAltitude(Number(e.target.value))}
              className="w-full accent-blue-400 bg-zinc-900 h-1.5 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* 3D Spread Styles selector */}
        <div className="flex items-center gap-2 border-t border-zinc-900/60 pt-3.5 mt-1">
          <span className="text-zinc-500">Perspective Layout:</span>
          {(['row', 'stack', 'spiral'] as const).map((style) => (
            <button
              key={style}
              onClick={() => setSpreadMode(style)}
              className={`px-3 py-1 rounded-md text-[10px] uppercase font-bold transition-all cursor-pointer ${
                spreadMode === style 
                  ? 'bg-zinc-800 text-white border border-zinc-700' 
                  : 'bg-zinc-950 text-zinc-600 hover:text-zinc-400 border border-transparent'
              }`}
            >
              {style === 'row' ? '3D Linear Row' : style === 'stack' ? 'Overlapping Cascade' : 'Helicopter Spiral'}
            </button>
          ))}
        </div>
      </div>

      {/* Main 3D Space Arena */}
      <div 
        className="relative w-full h-[500px] md:h-[600px] mt-28 md:mt-40 flex items-center justify-center overflow-visible"
        style={{ perspective: '1500px' }}
      >
        {/* Fututistic Grid Floor with dynamic scale adjustment representing dynamic map projection details */}
        <motion.div 
          className="absolute inset-0 w-[140%] h-[140%] left-[-20%] top-[-20%] pointer-events-none opacity-[0.06]"
          animate={{
            backgroundSize: presentationStep === 1 ? '52px 52px' : '36px 36px',
          }}
          transition={{
            type: 'spring',
            stiffness: 120,
            damping: 30,
          }}
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
            transform: `rotateX(${pitch}deg) rotateZ(${yaw}deg) translateZ(-160px)`
          }}
        />

        {/* Shadow floor indicator cast directly under the active card */}
        <div 
          className="absolute w-[240px] h-[340px] rounded-[45px] blur-[40px] opacity-35 transition-all duration-500 ease-out pointer-events-none"
          style={{
            backgroundColor: cards[activeIndex].color,
            transform: `rotateX(${pitch}deg) rotateZ(${yaw}deg) translateZ(-120px) scale(0.95)`,
          }}
        />

        {/* Dynamic Space Platform Layer rendering cards & floating holographic elements */}
        <div 
          className="relative w-full max-w-[240px] md:max-w-[280px] h-[350px] md:h-[410px] transition-transform duration-500 ease-out"
          style={{
            transformStyle: 'preserve-3d',
            transform: `rotateX(${pitch}deg) rotateZ(${yaw}deg)`,
          }}
        >
          {(() => {
            // Pre-calculate 3D spatial positions for all 26 nodes
            const computedNodes = spaceNodes.map((node) => {
              let tx = 0;
              let ty = 0;
              let tz = 0;
              let rotZ = 0;
              let scale = 1;
              let opacity = 1;

              const isCenter = node.isReal && node.realCardIndex === activeIndex;
              // Step 1 or 2: nodes >= 8 (I to Z) are hidden
              const isHidden = (activeIndex !== 2) && (node.idx >= 8);

              // Position engine mapping
              if (activeIndex === 0) {
                // Step 1: A is focused (-170, 0), H is far right (210, 0)
                if (node.idx <= 7) {
                  const t = node.idx / 7;
                  tx = -170 + 340 * t;
                  ty = 15 - 30 * t; // shingle diagonal
                  let baseZ = -30 + t * 45; // climb towards H
                  tz = isCenter ? baseZ + altitude : baseZ;
                  scale = node.isReal ? (isCenter ? 1.05 : 0.85) : 0.82;
                  opacity = node.isReal ? 1 : 0.45;
                } else {
                  // Offscreen right, invisible
                  tx = 450 + (node.idx - 8) * 8;
                  ty = 50;
                  tz = -350;
                  scale = 0.05;
                  opacity = 0;
                }
              } else if (activeIndex === 1) {
                // Step 2: H is focused (centered at 0), A is left (-250)
                if (node.idx <= 7) {
                  const t = node.idx / 7;
                  tx = -250 + 250 * t;
                  ty = 20 - 30 * t;
                  let baseZ = -35 + t * 50;
                  tz = isCenter ? baseZ + altitude : baseZ;
                  scale = node.isReal ? (isCenter ? 1.05 : 0.85) : 0.82;
                  opacity = node.isReal ? 1 : 0.45;
                } else {
                  // Offscreen right, invisible
                  tx = 450 + (node.idx - 8) * 8;
                  ty = 50;
                  tz = -350;
                  scale = 0.05;
                  opacity = 0;
                }
              } else {
                // Step 3: Z is focused! Entire stack expands across widescreen scale
                // A is left (-340), H is middle-left (-110), Z is right center (180)
                if (node.idx <= 7) {
                  // A to H range
                  const t = node.idx / 7;
                  tx = -320 + 190 * t;
                  ty = 30 - 25 * t;
                  let baseZ = -40 + t * 40;
                  tz = baseZ;
                  scale = node.isReal ? 0.85 : 0.82;
                  opacity = node.isReal ? 0.9 : 0.45;
                } else {
                  // H to Z range (17 nodes)
                  const t2 = (node.idx - 7) / 18;
                  tx = -130 + 290 * t2;
                  ty = 5 - 35 * t2;
                  let baseZ = 0 + t2 * 90;
                  tz = isCenter ? baseZ + altitude : baseZ;
                  scale = node.isReal ? (isCenter ? 1.05 : 0.85) : 0.82;
                  opacity = node.isReal ? 1 : 0.45;
                }
              }

              const letterZOffset = 420;

              return {
                node,
                tx,
                ty,
                tz,
                rotZ,
                scale,
                opacity,
                isCenter,
                isHidden,
                letterX: tx,
                letterY: ty,
                letterZ: tz + letterZOffset,
              };
            });

            // Draw a high-tech dotted neon tracking line linking all visible floating letters
            const visibleNodes = computedNodes.filter(n => !n.isHidden);
            const trackPoints: { x: number; y: number; z: number; color: string }[] = [];

            for (let s = 0; s < visibleNodes.length - 1; s++) {
              const pA = visibleNodes[s];
              const pB = visibleNodes[s + 1];
              const dotsPerSegment = pA.node.isReal || pB.node.isReal ? 3 : 2;
              
              for (let i = 0; i <= dotsPerSegment; i++) {
                const t = i / dotsPerSegment;
                const col = pA.node.color;
                trackPoints.push({
                  x: pA.letterX + t * (pB.letterX - pA.letterX),
                  y: pA.letterY + t * (pB.letterY - pA.letterY),
                  z: pA.letterZ + t * (pB.letterZ - pA.letterZ),
                  color: col,
                });
              }
            }

            return (
              <>
                {/* 1. Neon Virtual Parallel Grid Rail */}
                {trackPoints.map((pt, pIdx) => (
                  <motion.div
                    key={`track-bead-${pIdx}`}
                    className="absolute rounded-full pointer-events-none"
                    style={{
                      left: '50%',
                      top: '50%',
                      width: '3.5px',
                      height: '3.5px',
                      marginLeft: '-1.75px',
                      marginTop: '-1.75px',
                      backgroundColor: '#ffffff',
                      color: pt.color,
                      boxShadow: `0 0 4px #ffffff, 0 0 8px currentColor, 0 0 15px currentColor`,
                      transformStyle: 'preserve-3d',
                    }}
                    animate={{
                      x: pt.x,
                      y: pt.y,
                      z: pt.z,
                    }}
                    transition={{
                      type: 'spring',
                      stiffness: 240,
                      damping: 24,
                    }}
                  />
                ))}

                {/* 2. Vertical Laser Tether lines linking cards to floating letters */}
                {computedNodes.map((pos) => {
                  const isHidden = pos.isHidden;
                  if (isHidden) return null;
                  const letterZOffset = 420;
                  return (
                    <motion.div
                      key={`tether-${pos.node.letter}`}
                      className="absolute pointer-events-none"
                      style={{
                        left: '50%',
                        top: '50%',
                        width: '1px',
                        height: `${letterZOffset}px`,
                        marginLeft: '-0.5px',
                        marginTop: `-${letterZOffset / 2}px`,
                        transformStyle: 'preserve-3d',
                        background: `linear-gradient(to top, rgba(23, 23, 23, 0.1), ${pos.node.color}, rgba(255, 255, 255, 0.3))`,
                        boxShadow: `0 0 6px ${pos.node.color}80`,
                        opacity: pos.node.isReal ? (pos.isCenter ? 1 : 0.3) : 0.12,
                      }}
                      animate={{
                        x: pos.tx,
                        y: pos.ty,
                        z: pos.tz + (letterZOffset / 2),
                        rotateX: 90,
                      }}
                      transition={{
                        type: 'spring',
                        stiffness: 240,
                        damping: 24,
                        delay: (activeIndex === 2 && pos.node.idx >= 8) ? (pos.node.idx - 7) * 0.035 : 0
                      }}
                    />
                  );
                })}

                {/* 3. Floating 3D Holographic letters directly above cards */}
                {computedNodes.map((pos) => {
                  const isHidden = pos.isHidden;
                  if (isHidden) return null;
                  const isReal = pos.node.isReal;
                  const circleSize = isReal ? 64 : 36;
                  const fontSize = isReal ? 'text-2xl' : 'text-[11px]';
                  return (
                    <motion.div
                      key={`floating-letter-${pos.node.letter}`}
                      className="absolute pointer-events-none select-none flex items-center justify-center z-50"
                      style={{
                        left: '50%',
                        top: '50%',
                        width: `${circleSize}px`,
                        height: `${circleSize}px`,
                        marginLeft: `-${circleSize / 2}px`,
                        marginTop: `-${circleSize / 2}px`,
                        transformStyle: 'preserve-3d',
                      }}
                      animate={{
                        x: pos.tx,
                        y: pos.ty,
                        z: pos.letterZ,
                        rotateX: -90,
                        rotateY: 0,
                        rotateZ: pos.rotZ,
                        scale: isReal ? (pos.isCenter ? 1.25 : 0.9) : 0.8,
                      }}
                      transition={{
                        type: 'spring',
                        stiffness: 240,
                        damping: 24,
                        delay: (activeIndex === 2 && pos.node.idx >= 8) ? (pos.node.idx - 7) * 0.035 : 0
                      }}
                    >
                      {/* Pulsing Holo Ring */}
                      <motion.div
                        className="absolute inset-0 rounded-full border flex items-center justify-center bg-zinc-950/90 backdrop-blur-md"
                        style={{
                          borderColor: isReal ? pos.node.color : `${pos.node.color}50`,
                          borderWidth: isReal ? '2px' : '1px',
                          boxShadow: isReal 
                            ? `0 0 15px ${pos.node.color}b0, inset 0 0 10px ${pos.node.color}60`
                            : `0 0 6px ${pos.node.color}40`,
                        }}
                        animate={{
                          translateY: isReal ? [0, -6, 0] : [0, -3, 0],
                        }}
                        transition={{
                          duration: 3,
                          repeat: Infinity,
                          ease: 'easeInOut',
                          delay: pos.node.idx * 0.15,
                        }}
                      >
                        <span 
                          className={`${fontSize} font-black font-mono text-white select-none pointer-events-none`}
                          style={{
                            textShadow: isReal ? `0 0 8px ${pos.node.color}, 0 0 16px ${pos.node.color}` : undefined,
                          }}
                        >
                          {pos.node.letter}
                        </span>
                      </motion.div>
                    </motion.div>
                  );
                })}

                {/* 4. Underling standard functional & virtual 3D Cards */}
                {computedNodes.map((pos) => {
                  const node = pos.node;
                  const isHidden = pos.isHidden;

                  if (node.isReal) {
                    const card = node.realCard!;
                    const distance = node.realCardIndex! - activeIndex;
                    const isCenter = pos.isCenter;

                    return (
                      <motion.div
                        key={card.id}
                        id={`isometric-card-${card.id}`}
                        className="absolute inset-x-0 inset-y-0 rounded-[36deg] border bg-[#111318] flex flex-col justify-between cursor-pointer overflow-visible"
                        style={{
                          transformStyle: 'preserve-3d',
                          zIndex: 50 - Math.abs(distance),
                          borderColor: isCenter ? `${card.color}90` : 'rgba(255,255,255,0.06)',
                          boxShadow: isCenter
                            ? `0 25px 60px -15px ${card.color}40, 0 35px 80px -10px rgba(0,0,0,0.8), inset 0 1px 1px rgba(255,255,255,0.2)`
                            : '0 15px 35px -10px rgba(0,0,0,0.6)',
                          pointerEvents: isHidden ? 'none' : 'auto',
                        }}
                        animate={{
                          x: pos.tx,
                          y: pos.ty,
                          z: pos.tz,
                          rotateZ: pos.rotZ,
                          scale: pos.scale,
                          opacity: isHidden ? 0 : pos.opacity,
                        }}
                        whileHover={isHidden ? undefined : {
                          z: pos.tz + 30,
                          scale: pos.scale * 1.02,
                          transition: { type: 'spring', stiffness: 400, damping: 15 }
                        }}
                        transition={{
                          type: 'spring',
                          stiffness: 240,
                          damping: 24,
                          mass: 1,
                          delay: (activeIndex === 2 && node.idx >= 8) ? (node.idx - 7) * 0.035 : 0
                        }}
                        onClick={() => {
                          if (isCenter) {
                            onSelectCard(card);
                          } else {
                            setActiveIndex(node.realCardIndex!);
                          }
                        }}
                      >
                        {/* 3D Holographic Image Plate */}
                        <div className="relative h-[62%] bg-zinc-900 rounded-t-[36deg] overflow-hidden pointer-events-none">
                          <img
                            src={card.image}
                            alt={card.title}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover select-none"
                          />
                          {/* Neon spotlight effect on active card */}
                          {isCenter && (
                            <div className="absolute inset-0 bg-gradient-to-t from-[#111318] via-transparent opacity-85" />
                          )}
                          <div className="absolute inset-0 bg-gradient-to-b from-[#111318]/10 via-[#111318]/40 to-[#111318]" />

                          {/* Category Stamp */}
                          <div className="absolute top-4 left-4 flex gap-1.5 items-center bg-black/50 backdrop-blur-md px-3 py-1 rounded-full border border-white/5 text-[10px] font-mono tracking-wider uppercase"
                            style={{ color: card.color }}>
                            <Compass className="w-3 h-3 animate-spin duration-1000" style={{ animationDuration: '6s' }} />
                            {card.category}
                          </div>
                        </div>

                        {/* Highly immersive 3D Procedural Objects pop out perpendicular to card floor */}
                        <Isometric3DObjects cardId={card.id} color={card.color} isActive={isCenter} />

                        {/* Info Text panel */}
                        <div className="p-5 h-[38%] bg-[#111318] flex flex-col justify-between pointer-events-none select-none">
                          <div>
                            <h3 className="text-lg font-bold tracking-tight text-white font-sans leading-tight">
                              {card.title}
                            </h3>
                            <p className="text-[11px] text-zinc-400 font-mono mt-0.5 truncate uppercase tracking-tight">
                              {card.subtitle}
                            </p>
                          </div>

                          <div className="flex items-center justify-between border-t border-white/5 pt-3.5 text-[9px] font-mono text-zinc-500">
                            <span className="truncate max-w-[130px]">{card.coordinates}</span>
                            <span className="font-extrabold uppercase shrink-0" style={{ color: isCenter ? card.color : '#52525b' }}>
                              EXPLORE ↗
                            </span>
                          </div>
                        </div>
                      </motion.div>
                    );
                  } else {
                    // Virtual intermediate card elements (styled as elegant full-size shingled deck cards)
                    return (
                      <motion.div
                        key={`virtual-card-${node.letter}`}
                        className="absolute inset-x-0 inset-y-0 rounded-[36deg] border pointer-events-none"
                        style={{
                          transformStyle: 'preserve-3d',
                          zIndex: 10 + node.idx,
                          borderColor: `${node.color}25`,
                          backgroundColor: 'rgba(17, 19, 24, 0.55)',
                          boxShadow: `0 12px 40px -5px rgba(0,0,0,0.75), inset 0 1px 1px rgba(255,255,255,0.03)`,
                        }}
                        animate={{
                          x: pos.tx,
                          y: pos.ty,
                          z: pos.tz,
                          rotateZ: pos.rotZ,
                          scale: pos.scale,
                          opacity: isHidden ? 0 : pos.opacity,
                        }}
                        transition={{
                          type: 'spring',
                          stiffness: 240,
                          damping: 24,
                          mass: 1,
                          delay: (activeIndex === 2 && node.idx >= 8) ? (node.idx - 7) * 0.05 : 0
                        }}
                      >
                        {/* Subtle Techy internal lines indicating virtual structure */}
                        <div className="absolute inset-3 rounded-[28deg] border border-white/5 bg-zinc-950/20 flex flex-col items-center justify-between p-3.5 overflow-hidden">
                          <span className="text-[10px] font-mono text-zinc-600 self-start">0{node.idx}</span>
                          {/* Neon vertical alignment dots */}
                          <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: `${node.color}50`, boxShadow: `0 0 10px ${node.color}` }} />
                          <span className="text-[10px] font-mono text-zinc-600 uppercase tracking-widest">{node.letter}</span>
                        </div>
                      </motion.div>
                    );
                  }
                })}
              </>
            );
          })()}</div>
      </div>

      {/* Slide Navigation Buttons */}
      <div className="flex items-center justify-center gap-6 mt-4 relative z-10 w-full px-8">
        <button
          id="iso-prev-btn"
          onClick={(e) => { e.stopPropagation(); handlePrev(); }}
          className="p-3.5 rounded-full bg-zinc-900 border border-white/5 hover:border-white/20 text-zinc-400 hover:text-white transition-all hover:bg-zinc-800 flex items-center justify-center active:scale-90 shadow-lg cursor-pointer"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-1.5 bg-zinc-950/60 pb-1.5 pt-1 px-4 rounded-full border border-white/5 backdrop-blur-md">
          {cards.map((_, idx) => (
            <button
              key={idx}
              id={`iso-dot-${idx}`}
              onClick={(e) => { e.stopPropagation(); setActiveIndex(idx); }}
              className="group relative p-1.5 focus:outline-none cursor-pointer"
            >
              <div 
                className={`h-1.5 rounded-full transition-all duration-300 ${idx === activeIndex ? 'w-5' : 'w-1.5'}`} 
                style={{ 
                  backgroundColor: idx === activeIndex ? cards[activeIndex].color : '#52525b' 
                }} 
              />
            </button>
          ))}
        </div>

        <button
          id="iso-next-btn"
          onClick={(e) => { e.stopPropagation(); handleNext(); }}
          className="p-3.5 rounded-full bg-zinc-900 border border-white/5 hover:border-white/20 text-zinc-400 hover:text-white transition-all hover:bg-zinc-800 flex items-center justify-center active:scale-90 shadow-lg cursor-pointer"
        >
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>

      <p className="text-zinc-600 font-mono text-[10px] mt-4 select-none drop-shadow text-center">
        ⚡ TIPS: Try adjusting Pitch, Yaw and Active Lift sliders or use left/right arrow keys to customize the exact 45° perspective angle!
      </p>
    </div>
  );
}
