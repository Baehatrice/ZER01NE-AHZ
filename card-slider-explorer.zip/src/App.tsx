import React, { useState, useMemo, useEffect } from 'react';
import { CARD_ITEMS } from './data';
import { SliderMode, CardItem } from './types';
import CoverflowSlider from './components/CoverflowSlider';
import ThreeDStack from './components/ThreeDStack';
import FanDeckSlider from './components/FanDeckSlider';
import IsometricSlider from './components/IsometricSlider';
import CardDetail from './components/CardDetail';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, Sliders, Search, Compass, Map, Star, 
  Layers, Volume2, HelpCircle 
} from 'lucide-react';

export default function App() {
  const [activeMode, setActiveMode] = useState<SliderMode>('isometric');
  const [activeIndex, setActiveIndex] = useState(0);
  const [selectedCard, setSelectedCard] = useState<CardItem | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [isSpinning, setIsSpinning] = useState(false);

  // Expose unique categories
  const categories = useMemo(() => {
    const list = CARD_ITEMS.map(card => card.category);
    return ['All', ...Array.from(new Set(list))];
  }, []);

  // Filtered Cards according to Search & Category
  const filteredCards = useMemo(() => {
    return CARD_ITEMS.filter(card => {
      const matchSearch = card.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        card.subtitle.toLowerCase().includes(searchQuery.toLowerCase()) ||
        card.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCategory = selectedCategory === 'All' || card.category === selectedCategory;
      return matchSearch && matchCategory;
    });
  }, [searchQuery, selectedCategory]);

  // Handle activeIndex bounding safety during filter corrections
  useEffect(() => {
    if (activeIndex >= filteredCards.length) {
      setActiveIndex(Math.max(0, filteredCards.length - 1));
    }
  }, [filteredCards, activeIndex]);

  // Elegant gradual "촤라라락" machine spin simulator
  const handleSlotSpin = () => {
    if (isSpinning || filteredCards.length < 2) return;
    setIsSpinning(true);

    // Play quick physical start tic sound
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      gain.gain.setValueAtTime(0.05, ctx.currentTime);
      osc.start();
      osc.stop(ctx.currentTime + 0.1);
    } catch (e) {}

    // Gradually decelerating steps to mimic card dealer action ("촤라라락")
    const steps = [40, 40, 40, 40, 50, 50, 60, 70, 80, 100, 120, 150, 190, 240, 310, 400, 500];
    let stepCount = 0;

    const runRotate = () => {
      setActiveIndex(prev => (prev + 1) % filteredCards.length);
      
      // Secondary tactile audio tick
      try {
        const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(150 + (stepCount * 12), ctx.currentTime);
        gain.gain.setValueAtTime(0.02, ctx.currentTime);
        osc.start();
        osc.stop(ctx.currentTime + 0.04);
      } catch (e) {}

      stepCount++;
      if (stepCount < steps.length) {
        setTimeout(runRotate, steps[stepCount]);
      } else {
        setIsSpinning(false);
      }
    };

    setTimeout(runRotate, steps[0]);
  };

  const activeCard = filteredCards[activeIndex];

  return (
    <div 
      id="app-root-scaffold"
      className="min-h-screen bg-[#06070a] text-zinc-100 flex flex-col justify-between selection:bg-zinc-800 relative overflow-x-hidden antialiased"
    >
      {/* Immersive ambient glowing canvas orb */}
      <div 
        className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] rounded-full blur-[170px] opacity-[0.09] pointer-events-none transition-all duration-1000"
        style={{
          background: activeCard 
            ? `radial-gradient(circle, ${activeCard.color} 0%, rgba(0,0,0,0) 80%)`
            : 'radial-gradient(circle, #3b82f6 0%, rgba(0,0,0,0) 80%)'
        }}
      />

      {/* Top Navigation Bar */}
      <header className="border-b border-zinc-900/40 bg-zinc-950/40 backdrop-blur-md relative z-30 px-6 py-4.5">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div 
              className="p-2.5 rounded-xl border flex items-center justify-center transition-all duration-700"
              style={{ 
                borderColor: activeCard ? `${activeCard.color}25` : 'rgba(255,255,255,0.06)',
                backgroundColor: activeCard ? `${activeCard.color}0a` : 'transparent',
                boxShadow: activeCard ? `0 0 15px ${activeCard.color}0d` : 'none'
              }}
            >
              <Compass 
                className="w-5 h-5 transition-colors animate-spin" 
                style={{ 
                  color: activeCard ? activeCard.color : '#e4e4e7',
                  animationDuration: '12s' 
                }} 
              />
            </div>
            <div>
              <h1 className="text-lg font-black tracking-tight font-display text-white">
                CARD SLIDER STUDY
              </h1>
              <p className="text-[10px] text-zinc-500 font-mono">
                Interactive Multi-Layout Carousel System
              </p>
            </div>
          </div>

          {/* Controller Mode Toggles */}
          <div className="flex bg-zinc-950 border border-zinc-900/80 p-1.5 rounded-full select-none z-10 overflow-x-auto max-w-full">
            {[
              { mode: 'isometric', label: '45° Isometric Deck', icon: Sliders },
              { mode: 'coverflow', label: '3D Coverflow', icon: Compass },
              { mode: 'stack', label: 'Stacked Deck', icon: Layers },
              { mode: 'fan', label: 'Fan Spread', icon: Sliders },
            ].map((btn) => {
              const Icon = btn.icon;
              const isActive = activeMode === btn.mode;
              return (
                <button
                  key={btn.mode}
                  id={`mode-toggle-${btn.mode}`}
                  onClick={() => {
                    setActiveMode(btn.mode as SliderMode);
                    setActiveIndex(0);
                  }}
                  className={`px-4.5 py-1.5 rounded-full text-xs font-mono font-bold flex items-center gap-2 transition-all cursor-pointer ${
                    isActive 
                      ? 'bg-zinc-900 text-white shadow-md' 
                      : 'text-zinc-500 hover:text-zinc-350'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {btn.label}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Main Sandbox Workspace */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-6 py-6 flex flex-col justify-start relative z-10 font-sans">

        {/* Dynamic Empty State */}
        {filteredCards.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center py-20 text-center">
            <Compass className="w-12 h-12 text-zinc-700 mb-4 animate-pulse" />
            <h3 className="text-zinc-400 font-bold mb-1">No Cards Found</h3>
            <p className="text-zinc-650 text-xs font-mono max-w-sm">
              We couldn't find any destinations matching your current query. Try resetting your filter settings.
            </p>
            <button
              onClick={() => { setSearchQuery(''); setSelectedCategory('All'); }}
              className="mt-6 px-4.5 py-2 bg-zinc-900 border border-zinc-800 text-xs font-mono hover:text-white rounded-lg cursor-pointer"
            >
              RESET FILTERS
            </button>
          </div>
        ) : (
          <div className="relative mt-2">
            {/* Conditional slider rendering based on activeMode */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeMode}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.3 }}
              >
                {activeMode === 'isometric' && (
                  <IsometricSlider
                    cards={filteredCards}
                    activeIndex={activeIndex}
                    setActiveIndex={setActiveIndex}
                    onSelectCard={setSelectedCard}
                  />
                )}

                {activeMode === 'coverflow' && (
                  <CoverflowSlider
                    cards={filteredCards}
                    activeIndex={activeIndex}
                    setActiveIndex={setActiveIndex}
                    onSelectCard={setSelectedCard}
                  />
                )}

                {activeMode === 'stack' && (
                  <ThreeDStack
                    cards={filteredCards}
                    activeIndex={activeIndex}
                    setActiveIndex={setActiveIndex}
                    onSelectCard={setSelectedCard}
                  />
                )}

                {activeMode === 'fan' && (
                  <FanDeckSlider
                    cards={filteredCards}
                    activeIndex={activeIndex}
                    setActiveIndex={setActiveIndex}
                    onSelectCard={setSelectedCard}
                  />
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        )}

      </main>

      {/* Footer System Credits */}
      <footer className="border-t border-zinc-900/20 bg-zinc-950/20 py-6 px-8 flex flex-col md:flex-row items-center justify-between text-zinc-600 font-mono text-[10px] gap-4">
        <span>© 2026 Interactive Card Deck Lab</span>
        <div className="flex items-center gap-4">
          <span>MODE: {activeMode.toUpperCase()}</span>
          <span>CURATED: {CARD_ITEMS.length || 0} TOTAL ESCAPES</span>
        </div>
      </footer>

      {/* Immersive Inspection Detail Dialog */}
      <AnimatePresence>
        {selectedCard && (
          <CardDetail
            card={selectedCard}
            onClose={() => setSelectedCard(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
